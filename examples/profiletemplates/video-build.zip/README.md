# 本地视频合成与验收

使用 FFmpeg、Pillow 和中文字体组织图像、音频、字幕并生成视频，保存渲染命令及媒体验收报告；不内置 TTS 或生成视频模型。

This is a generated Docker build context, not a built image. Dependencies are downloaded during build.
The Codex version is fixed in Dockerfile; no build arguments are needed for RunDesk WebUI.
Upload this ZIP with Dockerfile at its root, build, then explicitly select the image for the application.
Skills live in /etc/codex/skills; seed/config.toml initializes missing config only. Existing config is not merged.
Use a new environment or apply the selected MCP configuration explicitly. Configure Codex authentication at runtime.
Run python3 /opt/rundesk-profile/tools/profile_doctor.py --json inside the deployed container.
Agent-Reach includes gh, mcporter, bird, undici and its Codex skill; mcporter seeds Exa into the runtime HOME on first use.
Cookies, proxies and optional external platform MCP services are configured at runtime; no browser or Docker socket is bundled.
Run agent-reach doctor after startup to check live channels; it is not a model or research acceptance test.
